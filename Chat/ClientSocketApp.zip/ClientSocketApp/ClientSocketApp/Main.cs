using System;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

class Program
{
    private static string _serverAddress = "127.0.0.1"; 
    private static int _port = 1802;
    
    static async Task Main(string[] args)
    {
        try
        {
            using (var client = new TcpClient(_serverAddress, _port))
            using (var stream = client.GetStream())
            using (var reader = new StreamReader(stream, Encoding.UTF8))
            using (var writer = new StreamWriter(stream, Encoding.UTF8) { AutoFlush = true })
            {
                Console.WriteLine("Connected to the server");

                // Solicitar nombre de usuario
                Console.Write("Ingrese su nombre: ");
                string userName = Console.ReadLine();

                // Verificar que el nombre no sea nulo o vacío
                if (string.IsNullOrWhiteSpace(userName))
                {
                    Console.WriteLine("Nombre no puede ser nulo.");
                    return;
                }

                // Enviar nombre de usuario al servidor
                await writer.WriteLineAsync(userName);

                // Leer la respuesta del servidor
                string response = await reader.ReadLineAsync();
                if (response != null)
                {
                    Console.WriteLine(response);
                    if (response.Contains("Cliente no autorizado."))
                    {
                        Console.WriteLine("Client identification failed or unauthorized.");
                        return;
                    }
                }

                // Escuchar mensajes del servidor
                Task.Run(async () =>
                {
                    while (true)
                    {
                        string serverMessage = await reader.ReadLineAsync();
                        if (serverMessage != null)
                        {
                            Console.WriteLine(serverMessage);
                        }
                        else
                        {
                            // La conexión fue cerrada por el servidor
                            Console.WriteLine("La conexión fue cerrada por el servidor");
                            break;
                        }
                    }
                });

                // Enviar mensajes al servidor
                while (true)
                {
                    string message = Console.ReadLine();
                    if (!string.IsNullOrWhiteSpace(message))
                    {
                        await writer.WriteLineAsync(message);
                    }
                }
            }
        }
        catch (IOException ex)
        {
            Console.WriteLine($"Error reading or writing data: {ex.Message}");
        }
        catch (SocketException ex)
        {
            Console.WriteLine($"Socket error: {ex.Message}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Unexpected error: {ex.Message}");
        }
    }
}
